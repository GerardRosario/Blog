/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mthree.Blog.config;

/**
 *
 * @author jerry
 */
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.provisioning.InMemoryUserDetailsManager;

@Configuration
@EnableWebSecurity
public class SecurityConfig extends WebSecurityConfigurerAdapter {

    @Autowired
    UserDetailsService userDetails;

//    @Autowired
//    public void configureGlobalInMemory(AuthenticationManagerBuilder auth) throws Exception {
//        auth
//                .inMemoryAuthentication()
//                .withUser("user").password("{noop}password").roles("USER")
//                .and()
//                .withUser("admin").password("{noop}password").roles("ADMIN", "USER");
//    }
    @Autowired
    public void configureGlobalInDB(AuthenticationManagerBuilder auth) throws Exception {
        auth.userDetailsService(userDetails).passwordEncoder(bCryptPasswordEncoder());
    }

    @Bean
    public BCryptPasswordEncoder bCryptPasswordEncoder() {
        return new BCryptPasswordEncoder();
    }
    
    @Override
    protected void configure(AuthenticationManagerBuilder auth) throws Exception {
        
        auth.inMemoryAuthentication()
        .passwordEncoder(bCryptPasswordEncoder())
            .withUser("admin")
        .password(bCryptPasswordEncoder().encode("password"))
        .roles("ADMIN", "MANAGER", "USER").and()
            .withUser("content1")
        .password(bCryptPasswordEncoder().encode("password"))
        .roles("MANAGER", "USER").and()
                .withUser("user1")
        .password(bCryptPasswordEncoder().encode("password"))
        .roles("USER");
                
        
    }

    @Override
    protected void configure(HttpSecurity http) throws Exception {
        http
                .authorizeRequests()
                .antMatchers("/", "/home").permitAll()
                .antMatchers( "/static").permitAll()
                .antMatchers( "/post").permitAll()
                .antMatchers( "/createUser").permitAll()
                .antMatchers( "/searchPost").permitAll()
                .antMatchers( "/editUser").hasAnyRole("ADMIN", "MANAGER","USER")
                .antMatchers( "/contentManager").hasAnyRole("ADMIN", "MANAGER")
                .antMatchers( "/editContent").hasAnyRole("ADMIN", "MANAGER")
                .antMatchers( "/createContent").hasAnyRole("ADMIN", "MANAGER")
                .antMatchers( "/userManager").hasRole("ADMIN")
                .antMatchers( "/tagManager").hasRole("ADMIN")
                .antMatchers( "/editComment").hasRole("ADMIN")
                .antMatchers("/css/**", "/js/**", "/fonts/**").permitAll()
                .anyRequest().hasRole("USER")
                .and()
                .formLogin()
                .loginPage("/login")
                .failureUrl("/login?login_error=1")
                .permitAll()
                .and()
                .logout()
                .logoutSuccessUrl("/")
                .permitAll();
    }
    
//    @Bean
//	@Override
//	public UserDetailsService userDetailsService() {
//		UserDetails user =
//			 User.withDefaultPasswordEncoder()
//				.username("admin")
//				.password("password")
//				.roles("USER")
//				.build();
//
//		return new InMemoryUserDetailsManager(user);
//	}

}