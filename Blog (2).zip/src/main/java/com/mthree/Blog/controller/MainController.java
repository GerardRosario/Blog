/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mthree.Blog.controller;

import com.mthree.Blog.dao.CommentDao;
import com.mthree.Blog.dao.ContentDao;
import com.mthree.Blog.dao.ContentDaoFileImpl;
import com.mthree.Blog.dao.TagDao;
import com.mthree.Blog.dao.TagDaoFileImpl;
import com.mthree.Blog.dao.TypeDao;
import com.mthree.Blog.dao.TypeDaoFileImpl;
import com.mthree.Blog.dao.UserDao;
import com.mthree.Blog.dao.UserDaoFileImpl;
import com.mthree.Blog.dto.Content;
import com.mthree.Blog.dto.Tag;
import java.util.ArrayList;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

/**
 *
 * @author jerry
 */
@Controller
public class MainController {
    
    
    @Autowired
    TypeDaoFileImpl roleDao;

    @Autowired
    UserDaoFileImpl userDao;

    @Autowired
    ContentDaoFileImpl contentDao;

    @Autowired
    TagDaoFileImpl tagDao;

    @Autowired
    CommentDao commentDao;
    
    @GetMapping({"/", "/home"})
    public String displayMainPage(Model model) {
        //set up nav bar
        List<Content> staticList = contentDao.getContentByType("static");
        model.addAttribute("staticList", staticList);

        //set up post list
//        List<Content> blogList = contentDao.getContentByType("blog");
//        for (Content blog : blogList) {
//            String content = blog.getContent();
//            String previewContent = content.substring(0, 200);
//            blog.setContent(previewContent);
//        }
//        model.addAttribute("blogList", blogList);
        List<Content> blogList = contentDao.getContentByType("blog");
        model.addAttribute("blogList", blogList);

        //set #hashtag side menu
        List<Tag> tagList = tagDao.readAllTags();
        List<Tag> tagList1 = new ArrayList<>();
        List<Tag> tagList2 = new ArrayList<>();
        //to arrange two hashtag column
        for (int i = 0; i < tagList.size(); i++) {
            if (i < tagList.size()/2) {
                tagList1.add(tagList.get(i));
            }
            if ( (i >= tagList.size()/2) ){
                tagList2.add(tagList.get(i));
            }
        }
        model.addAttribute("tagList1", tagList1);
        model.addAttribute("tagList2", tagList2);

        return "home";
    }
    
}
