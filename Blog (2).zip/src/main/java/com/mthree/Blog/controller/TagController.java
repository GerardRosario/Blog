/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mthree.Blog.controller;

import com.mthree.Blog.dao.CommentDaoFileImpl;
import com.mthree.Blog.dao.ContentDaoFileImpl;
import com.mthree.Blog.dao.TagDaoFileImpl;
import com.mthree.Blog.dao.TypeDaoFileImpl;
import com.mthree.Blog.dao.UserDaoFileImpl;
import com.mthree.Blog.dto.Tag;
import java.util.List;
import javax.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

/**
 *
 * @author jerry
 */
@Controller
public class TagController {
    @Autowired
    TypeDaoFileImpl roleDao;

    @Autowired
    UserDaoFileImpl userDao;

    @Autowired
    ContentDaoFileImpl contentDao;

    @Autowired
    TagDaoFileImpl tagDao;

    @Autowired
    CommentDaoFileImpl commentDao;

    @GetMapping("/tagManager")
    public String displatTagManager (Model model) {
        List<Tag> tagList = tagDao.readAllTags();
        model.addAttribute("tagList", tagList);

        return "tagManager";
    }


    @PostMapping("/createTag")
    public String createTag (HttpServletRequest request, Model model) {
        Tag tag = new Tag();
        tag.setName(request.getParameter("tag"));
        tagDao.createTag(tag);

        //set up tag table
        List<Tag> tagList = tagDao.readAllTags();
        model.addAttribute("tagList", tagList);

        return "redirect:/tagManager";
    }

    @GetMapping("deleteTag")
    public String deleteTag (HttpServletRequest request, Model model) {
        int id = Integer.parseInt(request.getParameter("id"));
        tagDao.deleteTag(id);

        //set up tag table
        List<Tag> tagList = tagDao.readAllTags();
        model.addAttribute("tagList", tagList);

        return "redirect:/tagManager";
    }

}
