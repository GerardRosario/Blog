/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mthree.Blog.controller;

import com.mthree.Blog.dao.CommentDaoFileImpl;
import com.mthree.Blog.dao.ContentDaoFileImpl;
import com.mthree.Blog.dao.TagDaoFileImpl;
import com.mthree.Blog.dao.TypeDaoFileImpl;
import com.mthree.Blog.dao.UserDaoFileImpl;
import com.mthree.Blog.dto.Comment;
import com.mthree.Blog.dto.Content;
import com.mthree.Blog.dto.User;
import java.time.LocalDateTime;
import java.util.List;
import javax.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

/**
 *
 * @author jerry
 */
@Controller
public class CommentController {
    
    @Autowired
    TypeDaoFileImpl roleDao;

    @Autowired
    UserDaoFileImpl userDao;

    @Autowired
    ContentDaoFileImpl contentDao;

    @Autowired
    TagDaoFileImpl tagDao;

    @Autowired
    CommentDaoFileImpl commentDao;
    
    @GetMapping("/addComment")
    public String addComment (Model model) {

        return "home";
    }

    @PostMapping("/addComment")
    public String addComment (HttpServletRequest request, Model model) {
        //set up post page
        int postId = Integer.parseInt(request.getParameter("postId"));
        Content content = contentDao.readContentById(postId);
        List<Comment> commentList = commentDao.getCommentByContentId(postId);
        List<Content> staticList = contentDao.getContentByType("static");
        model.addAttribute("content", content);
        model.addAttribute("commentList", commentList);
        model.addAttribute("staticList", staticList);
        //add new comment
        Comment comment = new Comment();
        comment.setDateCreated(LocalDateTime.now());
        comment.setComment(request.getParameter("comment"));
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        String userName = auth.getName();
        User commentUser = userDao.getUserByUsername(userName);
        comment.setUserId(commentUser);
        comment.setContentId(content);
        commentDao.createComment(comment);


        return "redirect:/post?id=" + postId;
    }

    @GetMapping("editComment")
    public String displayEditComment (HttpServletRequest request, Model model) {
        int id = Integer.parseInt(request.getParameter("id"));
        List<Comment> commentList = commentDao.getCommentByContentId(id);
        model.addAttribute("commentList", commentList);

        Content content = contentDao.readContentById(id);
        model.addAttribute(content);

        return "editComment";
    }

    @GetMapping("deleteComment")
    public String deleteComment (HttpServletRequest request, Model model) {
        int id = Integer.parseInt(request.getParameter("id"));
        int contentId = Integer.parseInt(request.getParameter("contentId"));
        commentDao.deleteComment(id);

        //set up comment table
        List<Comment> commentList = commentDao.readAllComments();
        model.addAttribute("commentList", commentList);
        model.addAttribute("id", contentId);
        return "redirect:/editComment?id="+contentId;
    }
    
}
