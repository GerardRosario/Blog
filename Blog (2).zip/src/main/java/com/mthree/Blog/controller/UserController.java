/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mthree.Blog.controller;

import com.mthree.Blog.dao.CommentDao;
import com.mthree.Blog.dao.CommentDaoFileImpl;
import com.mthree.Blog.dao.ContentDao;
import com.mthree.Blog.dao.ContentDaoFileImpl;
import com.mthree.Blog.dao.TagDao;
import com.mthree.Blog.dao.TagDaoFileImpl;
import com.mthree.Blog.dao.TypeDao;
import com.mthree.Blog.dao.TypeDaoFileImpl;
import com.mthree.Blog.dao.UserDao;
import com.mthree.Blog.dao.UserDaoFileImpl;
import com.mthree.Blog.dto.Content;
import com.mthree.Blog.dto.Type;
import com.mthree.Blog.dto.User;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import javax.servlet.http.HttpServletRequest;
import javax.validation.ConstraintViolation;
import javax.validation.Validation;
import javax.validation.Validator;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

/**
 *
 * @author jerry
 */
@Controller
public class UserController {
    
    @Autowired
    TypeDaoFileImpl roleDao;

    @Autowired
    UserDaoFileImpl userDao;

    @Autowired
    ContentDaoFileImpl contentDao;

    @Autowired
    TagDaoFileImpl tagDao;

    @Autowired
    CommentDaoFileImpl commentDao;
    
    @GetMapping("/userManager")
    public String displayUserManager(Model model) {
        //set up nav bar
        List<Content> staticList = contentDao.getContentByType("static");
        model.addAttribute("staticList", staticList);

        //set up user list
        List<User> userList = userDao.readAllUsers();
        model.addAttribute("userList", userList);

        return "userManager";
    }

    @GetMapping("/createUser")
    public String displayCreateUser(HttpServletRequest request, Model model) {
        //set up nav bar
        List<Content> staticList = contentDao.getContentByType("static");
        model.addAttribute("staticList", staticList);

        //set up form
        List<Type> roleList = roleDao.readAllTypes();
        model.addAttribute("roleList", roleList);

        String url = request.getHeader("referer");
        model.addAttribute("returnPage", url);

        return "createUser";
    }

    @PostMapping("/createUser")
    public String performCreateUser(HttpServletRequest request, Model model) {
        User user = new User();
        user.setUsername(request.getParameter("username"));
        user.setFirstName(request.getParameter("firstName"));
        user.setLastName(request.getParameter("lastName"));
        user.setEmail(request.getParameter("email"));
        user.setPhone(request.getParameter("phone"));
        //set password
        String rawPassword = request.getParameter("password");
        String encodedPassword = encodingPassword(rawPassword);
        if ( encodedPassword != user.getPassword()) {
            user.setPassword(encodedPassword);
        }
        //set role
        List<Type> allRole = roleDao.readAllTypes();
        List<Type> roleList = new ArrayList<>();
        for (Type role : allRole) {
            if(role.getName().equals("ROLE_USER")) {
                roleList.add(role);
            }
        }
        if (request.getParameter("picture").isEmpty()) {
            user.setPicture("https://i.ibb.co/rskNZpT/profile-pic-1.jpg");
        } else {
            user.setPicture(request.getParameter("picture"));
        }
        user.setUserType(roleList);
        user.setEnable(true);

        //validation
        Validator validate = Validation.buildDefaultValidatorFactory().getValidator();
        Set<ConstraintViolation<User>> errors = validate.validate(user);
        model.addAttribute("errors", errors);

        if (!errors.isEmpty()) {
            //set up nav bar
            List<Content> staticList = contentDao.getContentByType("static");
            model.addAttribute("staticList", staticList);

            //set up form
            roleList = roleDao.readAllTypes();
            model.addAttribute("roleList", roleList);

            model.addAttribute("user", user);
            model.addAttribute("errors", errors);
            return "createUser";
        }

        userDao.createUser(user);

        String returnPageStr = request.getParameter("returnPage");
        String returnPage = returnPageStr.substring(21, returnPageStr.length());
        String toReturn = "redirect:" + returnPage;

        return toReturn;
    }

    @GetMapping("/editUser")
    public String editUser(HttpServletRequest request, Model model){
        //set up nav bar
        List<Content> staticList = contentDao.getContentByType("static");
        model.addAttribute("staticList", staticList);

        //set up pre filled form
        List<Type> roleList = roleDao.readAllTypes();
        model.addAttribute("roleList", roleList);

        if(request.getParameter("id") != null) {
            //This is use when direct from userManager
            int id = Integer.parseInt(request.getParameter("id"));
            User user = userDao.readUserById(id);
            model.addAttribute("user", user);
        } else {
            //This is use when direct from editProfile
            Authentication auth = SecurityContextHolder.getContext().getAuthentication();
            String userName = auth.getName();
            User user = userDao.getUserByUsername(userName);
            model.addAttribute("user", user);
        }
        String url = request.getHeader("referer");
        model.addAttribute("returnPage", url);

        return "editUser";
    }

    @PostMapping("/editUser")
    public String performEditUser(HttpServletRequest request, Model model) {
        int userId = Integer.parseInt(request.getParameter("id"));
        User user = userDao.readUserById(userId);
        user.setUsername(request.getParameter("username"));
        user.setFirstName(request.getParameter("firstName"));
        user.setLastName(request.getParameter("lastName"));
        user.setEmail(request.getParameter("email"));
        user.setPhone(request.getParameter("phone"));
        //set password
        String rawPassword = request.getParameter("password");
        String currentPassword = user.getPassword();
        if ( !rawPassword.equals(currentPassword)) {
            String encodedPassword = encodingPassword(rawPassword);
            user.setPassword(encodedPassword);
        }
        //set role
        List<Type> roleList = new ArrayList<>();
        try{
            String[] roleIdList = request.getParameterValues("role"); // if not admin this will crash
            for (String roleId : roleIdList) {
                int id = Integer.parseInt(roleId);
                Type role = roleDao.readTypeById(id);
                roleList.add(role);
                user.setUserType(roleList);
            }
        } catch (NullPointerException ex) {

        }
        if (request.getParameter("enabled") != null) {
            boolean enable = Boolean.parseBoolean(request.getParameter("enabled"));
            user.setEnable(enable);
        }
        if (request.getParameter("picture").isEmpty()) {
            user.setPicture("https://i.ibb.co/rskNZpT/profile-pic-1.jpg");
        } else {
            user.setPicture(request.getParameter("picture"));
        }

        //validation
        Validator validate = Validation.buildDefaultValidatorFactory().getValidator();
        Set<ConstraintViolation<User>> errors = validate.validate(user);
        model.addAttribute("errors", errors);

        if (!errors.isEmpty()) {
            //set up nav bar
            List<Content> staticList = contentDao.getContentByType("static");
            model.addAttribute("staticList", staticList);

            //set up form
            roleList = roleDao.readAllTypes();
            model.addAttribute("roleList", roleList);

            model.addAttribute("user", user);
            model.addAttribute("errors", errors);
            return "editUser";
        }
        userDao.updateUser(user);

        //setup where to return to
        String returnPageStr = request.getParameter("returnPage");  //took from a page before edit
        String returnPage = returnPageStr.substring(21, returnPageStr.length());
        String toReturn = "redirect:" + returnPage;

        return toReturn;
    }

    @GetMapping("/deleteUser")
    public String deleteUser(HttpServletRequest request, Model model) {
        int userId = Integer.parseInt(request.getParameter("id"));
        userDao.deleteUser(userId);

        return "redirect:/userManager";
    }

    private String encodingPassword(String password) {
        String clearTxtPw = password;
        // BCrypt
        BCryptPasswordEncoder encoder = new BCryptPasswordEncoder();
        String hashedPw = encoder.encode(clearTxtPw);
        return hashedPw;
    }
    
}
