/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mthree.Blog.dto;

import java.time.LocalDateTime;
import java.util.List;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

/**
 *
 * @author jerry
 */
public class Content {
    private int id;

    private LocalDateTime dateCreated;

    @NotBlank(message = "Please enter title")
    @Size(max = 50, message= "Invalid title: Please enter title between 1-70 characters")
    private String title;

    @NotBlank(message = "Please enter content")
    @Size(max = 9999, message= "Invalid content: Please enter content between 1-9999 characters")
    private String content;

    @NotBlank(message = "Please enter type")
    private String type;

    @NotBlank(message = "Please enter status")
    private String status;

    private LocalDateTime launchDate;
    private LocalDateTime expiryDate;
    private String contPicture;
    private User user;

    @NotNull(message = "Please enter #hashtag")
    private List<Tag> tags;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public LocalDateTime getDateCreated() {
        return dateCreated;
    }

    public void setDateCreated(LocalDateTime createDate) {
        this.dateCreated = createDate;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public LocalDateTime getLaunchDate() {
        return launchDate;
    }

    public void setLaunchDate(LocalDateTime scheduleDate) {
        this.launchDate = scheduleDate;
    }

    public LocalDateTime getExpiryDate() {
        return expiryDate;
    }

    public void setExpiryDate(LocalDateTime expiryDate) {
        this.expiryDate = expiryDate;
    }

    public String getContPicture() {
        return contPicture;
    }

    public void setContPicture(String contPicture) {
        this.contPicture = contPicture;
    }

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }

    public List<Tag> getTags() {
        return tags;
    }

    public void setTags(List<Tag> tags) {
        this.tags = tags;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Content)) return false;

        Content content1 = (Content) o;

        if (getId() != content1.getId()) return false;
        if (getDateCreated() != null ? !getDateCreated().equals(content1.getDateCreated()) : content1.getDateCreated() != null)
            return false;
        if (getTitle() != null ? !getTitle().equals(content1.getTitle()) : content1.getTitle() != null) return false;
        if (getContent() != null ? !getContent().equals(content1.getContent()) : content1.getContent() != null)
            return false;
        if (getType() != null ? !getType().equals(content1.getType()) : content1.getType() != null) return false;
        if (getStatus() != null ? !getStatus().equals(content1.getStatus()) : content1.getStatus() != null)
            return false;
        if (getLaunchDate() != null ? !getLaunchDate().equals(content1.getLaunchDate()) : content1.getLaunchDate() != null)
            return false;
        if (getExpiryDate() != null ? !getExpiryDate().equals(content1.getExpiryDate()) : content1.getExpiryDate() != null)
            return false;
        if (getContPicture() != null ? !getContPicture().equals(content1.getContPicture()) : content1.getContPicture() != null)
            return false;
        if (getUser() != null ? !getUser().equals(content1.getUser()) : content1.getUser() != null) return false;
        return getTags() != null ? getTags().equals(content1.getTags()) : content1.getTags() == null;
    }

    @Override
    public int hashCode() {
        int result = getId();
        result = 31 * result + (getDateCreated() != null ? getDateCreated().hashCode() : 0);
        result = 31 * result + (getTitle() != null ? getTitle().hashCode() : 0);
        result = 31 * result + (getContent() != null ? getContent().hashCode() : 0);
        result = 31 * result + (getType() != null ? getType().hashCode() : 0);
        result = 31 * result + (getStatus() != null ? getStatus().hashCode() : 0);
        result = 31 * result + (getLaunchDate() != null ? getLaunchDate().hashCode() : 0);
        result = 31 * result + (getExpiryDate() != null ? getExpiryDate().hashCode() : 0);
        result = 31 * result + (getContPicture() != null ? getContPicture().hashCode() : 0);
        result = 31 * result + (getUser() != null ? getUser().hashCode() : 0);
        result = 31 * result + (getTags() != null ? getTags().hashCode() : 0);
        return result;
    }
}