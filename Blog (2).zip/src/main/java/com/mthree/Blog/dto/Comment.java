/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mthree.Blog.dto;

import java.time.LocalDateTime;

/**
 *
 * @author jerry
 */
public class Comment {
    private int id;
    private LocalDateTime dateCreated; 
    private String comment;
    private User userId; 
    private Content contentId;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public LocalDateTime getDateCreated() {
        return dateCreated;
    }

    public void setDateCreated(LocalDateTime dateCreated) {
        this.dateCreated = dateCreated;
    }

    public String getComment() {
        return comment;
    }

    public void setComment(String comment) {
        this.comment = comment;
    }

    public User getUserId() {
        return userId;
    }

    public void setUserId(User userId) {
        this.userId = userId;
    }

    public Content getContentId() {
        return contentId;
    }

    public void setContentId(Content contentId) {
        this.contentId = contentId;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Comment)) return false;

        Comment comment1 = (Comment) o;

        if (getId() != comment1.getId()) return false;
        if (getDateCreated() != null ? !getDateCreated().equals(comment1.getDateCreated()) : comment1.getDateCreated() != null)
            return false;
        if (getComment() != null ? !getComment().equals(comment1.getComment()) : comment1.getComment() != null)
            return false;
        if (getUserId() != null ? !getUserId().equals(comment1.getUserId()) : comment1.getUserId() != null) return false;
        return getContentId() != null ? getContentId().equals(comment1.getContentId()) : comment1.getContentId() == null;
    }

    @Override
    public int hashCode() {
        int result = getId();
        result = 31 * result + (getDateCreated() != null ? getDateCreated().hashCode() : 0);
        result = 31 * result + (getComment() != null ? getComment().hashCode() : 0);
        result = 31 * result + (getUserId() != null ? getUserId().hashCode() : 0);
        result = 31 * result + (getContentId() != null ? getContentId().hashCode() : 0);
        return result;
    }
}