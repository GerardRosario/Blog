/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mthree.Blog.dto;

import java.util.List;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;

/**
 *
 * @author jerry
 */
public class User {
    private int id;

    @NotBlank(message = "Please enter username")
    @Size(max = 50, message= "Invalid username: Please enter user between 1-70 characters")
    private String username;

    @NotBlank(message = "Please enter password")
    @Size(max = 100, message= "Invalid password: Please enter password between 1-100 characters")
    private String password;

    @NotBlank(message = "Please enter first name")
    @Size(max = 50, message= "Invalid first name: Please enter first name between 1-30 characters")
    private String firstName;

    @NotBlank(message = "Please enter last name")
    @Size(max = 50, message= "Invalid last name: Please enter last name between 1-30 characters")
    private String lastName;

    @NotBlank(message = "Please enter Email")
    @Size(max = 50, message= "Invalid Email: Please enter Email between 1-30 characters")
    private String email;

    @Size(max = 10, message= "Invalid URL: Please enter valid phone number")
    private String phone;

    @Size(max = 255, message= "Invalid URL: please enter URL between 1-255 characters")
    private String picture;

    private boolean enable;
    private List<Type> userType;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getPicture() {
        return picture;
    }

    public void setPicture(String picture) {
        this.picture = picture;
    }

    public boolean isEnable() {
        return enable;
    }

    public void setEnable(boolean enable) {
        this.enable = enable;
    }

    public List<Type> getUserType() {
        return userType;
    }

    public void setUserType(List<Type> type) {
        this.userType = type;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof User)) return false;

        User user = (User) o;

        if (getId() != user.getId()) return false;
        if (isEnable() != user.isEnable()) return false;
        if (getUsername() != null ? !getUsername().equals(user.getUsername()) : user.getUsername() != null)
            return false;
        if (getPassword() != null ? !getPassword().equals(user.getPassword()) : user.getPassword() != null)
            return false;
        if (getFirstName() != null ? !getFirstName().equals(user.getFirstName()) : user.getFirstName() != null)
            return false;
        if (getLastName() != null ? !getLastName().equals(user.getLastName()) : user.getLastName() != null)
            return false;
        if (getEmail() != null ? !getEmail().equals(user.getEmail()) : user.getEmail() != null) return false;
        if (getPhone() != null ? !getPhone().equals(user.getPhone()) : user.getPhone() != null) return false;
        if (getPicture() != null ? !getPicture().equals(user.getPicture()) : user.getPicture() != null)
            return false;
        return getUserType() != null ? getUserType().equals(user.getUserType()) : user.getUserType() == null;
    }

    @Override
    public int hashCode() {
        int result = getId();
        result = 31 * result + (getUsername() != null ? getUsername().hashCode() : 0);
        result = 31 * result + (getPassword() != null ? getPassword().hashCode() : 0);
        result = 31 * result + (getFirstName() != null ? getFirstName().hashCode() : 0);
        result = 31 * result + (getLastName() != null ? getLastName().hashCode() : 0);
        result = 31 * result + (getEmail() != null ? getEmail().hashCode() : 0);
        result = 31 * result + (getPhone() != null ? getPhone().hashCode() : 0);
        result = 31 * result + (getPicture() != null ? getPicture().hashCode() : 0);
        result = 31 * result + (isEnable() ? 1 : 0);
        result = 31 * result + (getUserType() != null ? getUserType().hashCode() : 0);
        return result;
    }
}