/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mthree.Blog.dao;

import com.mthree.Blog.dao.ContentDaoFileImpl.ContentMapper;
import com.mthree.Blog.dao.TagDaoFileImpl.TagMapper;
import com.mthree.Blog.dao.TypeDaoFileImpl.TypeMapper;
import com.mthree.Blog.dao.UserDaoFileImpl.UserMapper;
import com.mthree.Blog.dto.Comment;
import com.mthree.Blog.dto.Content;
import com.mthree.Blog.dto.Tag;
import com.mthree.Blog.dto.Type;
import com.mthree.Blog.dto.User;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

/**
 *
 * @author jerry
 */
@Repository
public class CommentDaoFileImpl implements CommentDao {

    @Autowired
    JdbcTemplate jdbc;
    
    public static final class CommentMapper implements RowMapper<Comment> {
        @Override
        public Comment mapRow(ResultSet resultSet, int i) throws SQLException {
            Comment comment = new Comment();

            comment.setId(resultSet.getInt("id"));
            comment.setDateCreated(resultSet.getTimestamp("dateCreated").toLocalDateTime());
            comment.setComment(resultSet.getString("comment"));

            return comment;
        }

    }

    @Override
    public Comment createComment(Comment model) {
        //add to
        final String INSERT_COMMENT = "INSERT INTO comment(dateCreated, comment, userId, contentId) VALUES (?,?,?,?)";
        jdbc.update(INSERT_COMMENT, model.getDateCreated(), model.getComment(), model.getUserId().getId(), model.getContentId().getId());

        int newId = jdbc.queryForObject("SELECT LAST_INSERT_ID()", Integer.class);
        model.setId(newId);

        return model;
    }

    @Override
    public List<Comment> readAllComments() {
        final String SELECT_ALL_COMMENT = "SELECT * FROM comment";
        List<Comment> commentList = jdbc.query(SELECT_ALL_COMMENT, new CommentMapper());

        associateUserComment(commentList);
        associateContentComment(commentList);

        return commentList;
    }

    @Override
    public Comment readCommentById(int id) {
        final String SELECT_COMMENT_BY_ID = "SELECT * FROM comment WHERE id = ?";
        Comment comment = jdbc.queryForObject(SELECT_COMMENT_BY_ID, new CommentMapper(), id);

        comment.setUserId(getUserForComment(comment.getId()));
        comment.setContentId(getContentForComment(comment.getId()));

        return comment;
    }

    @Override
    public void updateComment(Comment model) {
        final String UPDATE_COMMENT = "UPDATE comment SET " +
                "dateCreated = ?, " +
                "comment = ?, " +
                "userId = ?, " +
                "contentId = ? " +
                "WHERE id = ?";
        jdbc.update(UPDATE_COMMENT,  model.getDateCreated(), model.getComment(), model.getUserId().getId(), model.getContentId().getId(), model.getId());
    }

    @Override
    public void deleteComment(int id) {
        final String DELETE_COMMENT = "DELETE FROM comment WHERE id = ?";
        jdbc.update(DELETE_COMMENT, id);
    }

    public User getUserForComment(int commentId) {
        final String SELECT_USER_BY_COMMENT_ID = "SELECT u.* FROM user u " +
                "JOIN comment c ON u.id = c.userId " +
                "WHERE c.id = ?";
        User user = jdbc.queryForObject(SELECT_USER_BY_COMMENT_ID, new UserMapper(), commentId);
        user.setUserType(getTypeForUser(user.getId()));
        return user;
    }

    private void associateUserComment(List<Comment> commentList) {
        for(Comment comment : commentList) {
            User user = getUserForComment(comment.getId());
            comment.setUserId(user);
        }
    }

    public Content getContentForComment(int commentId) {
        final String SELECT_CONTENT_BY_COMMENT_ID = "SELECT ct.* FROM content ct " +
                "JOIN comment cm ON ct.id = cm.contentId " +
                "WHERE cm.id = ?";
        Content content = jdbc.queryForObject(SELECT_CONTENT_BY_COMMENT_ID, new ContentMapper(), commentId);
        content.setUser(getUserForContent(content.getId()));
        content.setTags(getTagsForContent(content.getId()));
        return content;
    }

    private void associateContentComment(List<Comment> commentList) {
        for(Comment comment : commentList) {
            Content content = getContentForComment(comment.getId());
        }
    }

    public List<Type> getTypeForUser(int userId) {
        final String SELECT_ROLE_BY_USER_ID = "SELECT t.* FROM type t " +
                "JOIN user_type ut ON t.Id = ut.roleId " +
                "WHERE ut.userId = ?";
        return jdbc.query(SELECT_ROLE_BY_USER_ID, new TypeMapper(), userId);
    }

    public User getUserForContent(int contentId) {
        final String SELECT_USER_BY_CONTENT_ID = "SELECT u.* FROM user u " +
                "JOIN content c ON u.Id = c.userId " +
                "WHERE c.id = ?";
        User user = jdbc.queryForObject(SELECT_USER_BY_CONTENT_ID, new UserMapper(), contentId);
        user.setUserType(getTypeForUser(user.getId()));
        return user;
    }

    public List<Tag> getTagsForContent(int contentId) {
        final String SELECT_TAG_BY_CONTENT_ID = "SELECT t.* FROM tag t " +
                "JOIN content_tag ct ON t.id = ct.tagId " +
                "WHERE ct.contentId = ?";
        return jdbc.query(SELECT_TAG_BY_CONTENT_ID, new TagMapper(), contentId);
    }
    public List<Comment> getCommentByContentId(int contentId) {
        final String SELECT_COMMENT_BY_CONTENT = "SELECT * FROM comment WHERE contentId = ?";
        List<Comment> commentList =  jdbc.query(SELECT_COMMENT_BY_CONTENT, new CommentMapper(), contentId);
        associateContentComment(commentList);
        associateUserComment(commentList);

        return commentList;
    }
    
}
