/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mthree.Blog.dao;

import com.mthree.Blog.dto.Tag;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

/**
 *
 * @author jerry
 */
@Repository
public class TagDaoFileImpl implements TagDao {
    
    @Autowired
    JdbcTemplate jdbc;
    
    public static final class TagMapper implements RowMapper<Tag> {
        @Override
        public Tag mapRow(ResultSet resultSet, int i) throws SQLException {

            Tag tag = new Tag();

            tag.setId(resultSet.getInt("id"));
            tag.setName(resultSet.getString("name"));

            return tag;
        }
    }
    
    @Override
    @Transactional
    public Tag createTag(Tag model) {
        final String INSERT_TAG = "INSERT INTO tag (name) VALUES (?)";
        jdbc.update(INSERT_TAG, model.getName());

        int newId = jdbc.queryForObject("SELECT LAST_INSERT_ID()", Integer.class);
        model.setId(newId);

        return model;
    }

    @Override
    public List<Tag> readAllTags() {
        final String SELECT_ALL_TAG = "SELECT * FROM tag";
        return jdbc.query(SELECT_ALL_TAG, new TagMapper());
    }

    @Override
    public Tag readTagById(int id) {
        try {
            final String SELECT_TAG_BY_ID = "SELECT * FROM tag WHERE id = ?";
            return jdbc.queryForObject(SELECT_TAG_BY_ID, new TagMapper(), id);
        } catch (DataAccessException ex) {
            return null;
        }
    }

    @Override
    @Transactional
    public void updateTag(Tag model) {
        final String UPDATE_TAG = "UPDATE tag SET name = ? WHERE id = ?";
        jdbc.update(UPDATE_TAG, model.getName(), model.getId());
    }

    @Override
    public void deleteTag(int id) {
        final String DELETE_CONTENT_TAG = "DELETE FROM content_tag WHERE tagId = ?";
        jdbc.update(DELETE_CONTENT_TAG, id);

        final String DELETE_TAG = "DELETE FROM tag WHERE id = ?";
        jdbc.update(DELETE_TAG, id);
    }
    
}
