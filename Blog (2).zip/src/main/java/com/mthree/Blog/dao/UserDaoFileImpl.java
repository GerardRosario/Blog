/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mthree.Blog.dao;

import com.mthree.Blog.dao.ContentDaoFileImpl.ContentMapper;
import com.mthree.Blog.dao.TypeDaoFileImpl.TypeMapper;
import com.mthree.Blog.dto.Content;
import com.mthree.Blog.dto.Type;
import com.mthree.Blog.dto.User;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

/**
 *
 * @author jerry
 */
@Repository
public class UserDaoFileImpl implements UserDao {
    
    @Autowired
    JdbcTemplate jdbc;
    
    public static final class UserMapper implements RowMapper<User> {
        @Override
        public User mapRow(ResultSet resultSet, int i) throws SQLException {
            User user = new User();

            user.setId(resultSet.getInt("id"));
            user.setUsername(resultSet.getString("username"));
            user.setPassword(resultSet.getString("password"));
            user.setFirstName(resultSet.getString("firstname"));
            user.setLastName(resultSet.getString("lastname"));
            user.setEmail(resultSet.getString("email"));
            user.setPhone(resultSet.getString("phone"));
            user.setPicture(resultSet.getString("picture"));
            user.setEnable(resultSet.getBoolean("enable"));

            return user;
        }
    }
    
    @Override
    @Transactional
    public User createUser(User model) {
        final String INSERT_USER = "INSERT INTO user (username, password, firstName, lastName, email, phone, picture, enable) VALUES (?,?,?,?,?,?,?,?)";
        jdbc.update(INSERT_USER, model.getUsername(), model.getPassword(), model.getFirstName(), model.getLastName(), model.getEmail(), model.getPhone(), model.getPicture(), model.isEnable());
        int newId = jdbc.queryForObject("SELECT LAST_INSERT_ID()", Integer.class);
        model.setId(newId);
        insertIntoUserType(model);
        return model;
    }

    @Override
    public List<User> readAllUsers() {
        final String SELECT_ALL_USERS = "SELECT * FROM user";
        List<User> userList = jdbc.query(SELECT_ALL_USERS, new UserMapper());
        associateUserType(userList);

        return userList;
    }

    @Override
    public User readUserById(int id) {
        try {
            final String SELECT_USER_BY_ID = "SELECT * FROM user WHERE id = ?";
            User user = jdbc.queryForObject(SELECT_USER_BY_ID, new UserMapper(), id);
            user.setUserType(getTypeForUser(user.getId()));
            return user;
        } catch (DataAccessException ex) {
            return null;
        }
    }

    @Override
    @Transactional
    public void updateUser(User model) {
        final String UPDATE_USER = "UPDATE user SET " +
                "username = ?, " +
                "password = ?, " +
                "firstName = ?, " +
                "lastName = ?, " +
                "email = ?, " +
                "phone = ?, " +
                "picture = ?, " +
                "enable = ? " +
                "WHERE id = ?";
        jdbc.update(UPDATE_USER, model.getUsername(), model.getPassword(), model.getFirstName(), model.getLastName(), model.getEmail(), model.getPhone(), model.getPicture(), model.isEnable(), model.getId());

        final String DELETE_USER_ROLE = "DELETE FROM user_type WHERE userId = ?";
        jdbc.update(DELETE_USER_ROLE, model.getId());

        insertIntoUserType(model);
    }

    @Override
    @Transactional
    public void deleteUser(int id) {
        final String SELECT_CONTENT_BY_USER_ID = "SELECT * FROM content WHERE userId = ?";
        List<Content> contentList = jdbc.query(SELECT_CONTENT_BY_USER_ID, new ContentMapper(), id);
        for (Content content : contentList) {
            final String DELETE_CONTENT_TAG = "DELETE FROM content_tag WHERE contentId = ?";
            jdbc.update(DELETE_CONTENT_TAG, content.getId());

            final String DELETE_COMMENT = "DELETE FROM comment WHERE contentId = ?";
            jdbc.update(DELETE_COMMENT, content.getId());

            final String DELETE_CONTENT = "DELETE FROM content WHERE id = ?";
            jdbc.update(DELETE_CONTENT, content.getId());
        }

//        //delete for content
//        final String DELETE_COMMENT_FOR_CONTENT = "DELETE FROM comment cm " +
//                "JOIN content ct ON ct.id = cm.contentId " +
//                "WHERE ct.userId = ?";
//        jdbc.update(DELETE_COMMENT_FOR_CONTENT, id);
//
//        final String DELETE_CONTENT_TAG_FOR_CONTENT = "DELETE FROM content_tag ct " +
//                "JOIN content c ON c.id = ct.contentId " +
//                "WHERE cn.userId = ?";
//        jdbc.update(DELETE_CONTENT_TAG_FOR_CONTENT, id);
//
//        final String DELETE_CONTENT = "DELETE FROM content c " +
//                "WHERE userId = ?";
//        jdbc.update(DELETE_CONTENT, id);

        //start delete other things
        final String DELETE_COMMENT = "DELETE FROM comment WHERE userId = ?";
        jdbc.update(DELETE_COMMENT, id);

        final String DELETE_USER_ROLE = "DELETE FROM user_type WHERE userId = ?";
        jdbc.update(DELETE_USER_ROLE, id);

        final String DELETE_USER = "DELETE FROM user WHERE id = ?";
        jdbc.update(DELETE_USER, id);
    }

    private void insertIntoUserType(User user) {
        final String INSERT_USER_ROLE = "INSERT INTO user_type (userId, roleId) VALUES (?,?)";
        for (Type role : user.getUserType()) {
            jdbc.update(INSERT_USER_ROLE, user.getId(), role.getId());
        }
    }
    
    public List<Type> getTypeForUser(int userId) {
        final String SELECT_ROLE_BY_USER_ID = "SELECT t.* FROM type t " +
                "JOIN user_type ut ON t.Id = ut.roleId " +
                "WHERE ut.userId = ?";
        return jdbc.query(SELECT_ROLE_BY_USER_ID, new TypeMapper(), userId);
    }

    private void associateUserType(List<User> userList) {
        for (User user : userList) {
            List<Type> roleList = getTypeForUser(user.getId());
            user.setUserType(roleList);
        }
    }
    
 
    public User getUserByUsername(String username) {
        try {
            final String SELECT_USER_BY_USERNAME = "SELECT * FROM user WHERE username = ?";
            User user = jdbc.queryForObject(SELECT_USER_BY_USERNAME, new UserMapper(), username);
            user.setUserType(getTypeForUser(user.getId()));
            return user;
        } catch (DataAccessException ex) {
            return null;
        }
    }
    
}
