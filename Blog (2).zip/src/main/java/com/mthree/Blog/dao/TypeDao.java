/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package com.mthree.Blog.dao;

import com.mthree.Blog.dto.Type;
import java.util.List;

/**
 *
 * @author jerry
 */
public interface TypeDao {
    public List<Type> readAllTypes();
    public Type readTypeById(int id);
    public Type createType(Type model);
    public void updateType(Type model);
    public void deleteType(int id);
    
}
