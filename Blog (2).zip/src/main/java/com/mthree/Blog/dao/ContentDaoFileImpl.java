/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mthree.Blog.dao;

import com.mthree.Blog.dao.TagDaoFileImpl.TagMapper;
import com.mthree.Blog.dao.TypeDaoFileImpl.TypeMapper;
import com.mthree.Blog.dao.UserDaoFileImpl.UserMapper;
import com.mthree.Blog.dto.Content;
import com.mthree.Blog.dto.Tag;
import com.mthree.Blog.dto.Type;
import com.mthree.Blog.dto.User;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

/**
 *
 * @author jerry
 */
@Repository
public class ContentDaoFileImpl implements ContentDao{
    
    @Autowired
    JdbcTemplate jdbc;
    
    
    public static final class ContentMapper implements RowMapper<Content> {

        @Override
        public Content mapRow(ResultSet resultSet, int i) throws SQLException {
            Content content = new Content();

            content.setId(resultSet.getInt("id"));
            content.setDateCreated(resultSet.getTimestamp("dateCreated").toLocalDateTime());
            content.setTitle(resultSet.getString("title"));
            content.setType(resultSet.getString("type"));
            content.setStatus(resultSet.getString("status"));
            content.setContent(resultSet.getString("content"));
            content.setContPicture("contPicture");
            if (resultSet.getTimestamp("launchDate") != null) {
                content.setLaunchDate(resultSet.getTimestamp("launchDate").toLocalDateTime());
            }
            if (resultSet.getTimestamp("expiryDate") != null) {
                content.setExpiryDate(resultSet.getTimestamp("expiryDate").toLocalDateTime());
            }
            content.setContPicture(resultSet.getString("contPicture"));

            return content;
        }
    }

    @Override
    public Content createContent(Content model) {
        //add content to db
        final String INSERT_CONTENT = "INSERT INTO content (dateCreated, title, type, status, content, launchDate, expiryDate, contPicture, userId) VALUE (?,?,?,?,?,?,?,?,?)";
        jdbc.update(INSERT_CONTENT, model.getDateCreated(), model.getTitle(), model.getType(), model.getStatus(), model.getContent(), model.getLaunchDate(), model.getExpiryDate(), model.getContPicture(), model.getUser().getId());
        //get recent insert id and set it in content object
        int newId = jdbc.queryForObject("SELECT LAST_INSERT_ID()", Integer.class);
        model.setId(newId);

        //insert into bridge table
        insertIntoContentTag(model);

        return model;
    }

    @Override
    public List<Content> readAllContent() {
        final String SELECT_ALL_CONTENT = "SELECT * FROM content ORDER BY launchDate";
        List<Content> contentList = jdbc.query(SELECT_ALL_CONTENT, new ContentMapper());
        //add user object to each content in the list
        associateUserContent(contentList);
        //add tags to each content in the list
        associateContentTag(contentList);

        return contentList;
    }

    @Override
    public Content readContentById(int id) {
        final String SELECT_CONTENT_BY_ID = "SELECT * FROM content WHERE id = ?";
        Content content = jdbc.queryForObject(SELECT_CONTENT_BY_ID, new ContentMapper(), id);

        //set user and tags to content object
        content.setUser(getUserForContent(content.getId()));
        content.setTags(getTagsForContent(content.getId()));


        return content;
    }

    @Override
    public void updateContent(Content model) {
        final String UPDATE_CONTENT = "UPDATE content SET " +
                "dateCreated = ?, " +
                "title = ?, " +
                "type = ?, " +
                "status = ?, " +
                "content = ?, " +
                "launchDate = ?, " +
                "expiryDate = ?, " +
                "contPicture = ?, " +
                "userId = ? " +
                "WHERE id = ?";
        jdbc.update(UPDATE_CONTENT, model.getDateCreated(), model.getTitle(), model.getType(), model.getStatus(), model.getContent(), model.getLaunchDate(), model.getExpiryDate(), model.getContPicture(), model.getUser().getId(), model.getId());

        //delete all tags in content_tag so we can update new list to it
        final String DELETE_CONTENT_TAG = "DELETE FROM content_tag WHERE contentId = ?";
        jdbc.update(DELETE_CONTENT_TAG, model.getId());

        insertIntoContentTag(model);
    }

    @Override
    public void deleteContent(int id) {
        //delete from other table that has content id first before delete the actual delete row
        final String DELETE_CONTENT_TAG = "DELETE FROM content_tag WHERE contentId = ?";
        jdbc.update(DELETE_CONTENT_TAG, id);

        final String DELETE_COMMENT = "DELETE FROM comment WHERE contentId = ?";
        jdbc.update(DELETE_COMMENT, id);

        final String DELETE_CONTENT = "DELETE FROM content WHERE id = ?";
        jdbc.update(DELETE_CONTENT, id);

    }

    private void insertIntoContentTag (Content content) {
        //loop from tag array in content
        for(Tag tag : content.getTags()) {
            final String INSERT_CONTENT_TAG = "INSERT INTO content_tag (contentId, tagId) VALUES (?,?)";
            jdbc.update(INSERT_CONTENT_TAG, content.getId(), tag.getId());
        }
    }

    public User getUserForContent(int contentId) {
        //get user object for content
        final String SELECT_USER_BY_CONTENT_ID = "SELECT u.* FROM user u " +
                "JOIN content c ON u.Id = c.userId " +
                "WHERE c.id = ?";
        User user = jdbc.queryForObject(SELECT_USER_BY_CONTENT_ID, new UserMapper(), contentId);
        user.setUserType(getTypeForUser(user.getId()));
        return user;
    }

    private void associateUserContent(List<Content> contentList) {
        //add user for each content
        for (Content content : contentList) {
            User user = getUserForContent(content.getId());
            content.setUser(user);
        }
    }

    public List<Tag> getTagsForContent(int contentId) {
        //get array of tag for content
        final String SELECT_TAG_BY_CONTENT_ID = "SELECT t.* FROM tag t " +
                "JOIN content_tag ct ON t.id = ct.tagId " +
                "WHERE ct.contentId = ?";
        return jdbc.query(SELECT_TAG_BY_CONTENT_ID, new TagMapper(), contentId);
    }

    private void associateContentTag(List<Content> contentList) {
        //add tags array for each content
        for (Content content : contentList) {
            List<Tag> tagList = getTagsForContent(content.getId());
            content.setTags(tagList);
        }
    }

    public List<Type> getTypeForUser(int userId) {
        //user need to have a role. This add a role to the user
        final String SELECT_ROLE_BY_USER_ID = "SELECT t.* FROM type t " +
                "JOIN user_type ut ON t.Id = ut.roleId " +
                "WHERE ut.userId = ?";
        return jdbc.query(SELECT_ROLE_BY_USER_ID, new TypeMapper(), userId);
    }

    public List<Content> getContentByType (String type) {
        List<Content> contentList = this.readAllContent();
        contentList = filterScheduleExpiredDate(contentList);
        List<Content> typeList = new ArrayList();
        //filter list of content base on the string type
        for (Content content : contentList) {
            if (content.getType().equals(type) && content.getStatus().equals("public")) {
                typeList.add(content);
            }
        }
        return typeList;
    }

    public List<Content> getContentByTag (int tagId) {
        //filter using sql query instead of using java
        final String SELECT_CONTENT_BY_TAG = "SELECT c.* FROM content c " +
                "JOIN content_tag ct ON ct.contentId = c.id " +
                "WHERE ct.tagId = ? and c.status = ?";
        List<Content> contentList =  jdbc.query(SELECT_CONTENT_BY_TAG, new ContentMapper(), tagId, "public");
        //take out expired content
        contentList = filterScheduleExpiredDate(contentList);
        //fill out tags and user
        associateContentTag(contentList);
        associateUserContent(contentList);
        return contentList;
    }

    public List<Content> getContentBySearchTitle(String searchText) {
        //filter using sql query
        searchText = "%" + searchText + "%";
        final String SELECT_CONTENT_BY_SEARCH_TITLE = "SELECT * FROM content WHERE title LIKE ?";
        List<Content> contentList = jdbc.query(SELECT_CONTENT_BY_SEARCH_TITLE, new ContentMapper(), searchText);
        //take out expired content
        contentList = filterScheduleExpiredDate(contentList);
        //fill out tags and user
        associateContentTag(contentList);
        associateUserContent(contentList);

        return contentList;
    }

    public List<Content> filterScheduleExpiredDate (List<Content>blogList) {
        //filter out expired content
        List<Content> filteredBlogList = new ArrayList<>();
        for (Content blog : blogList) {
            if (blog.getExpiryDate() != null) {
                if (LocalDateTime.now().isAfter(blog.getLaunchDate()) && LocalDateTime.now().isBefore(blog.getExpiryDate())) {
                    filteredBlogList.add(blog);
                }
            } else {
                if (blog.getLaunchDate().isBefore(LocalDateTime.now())) {
                    filteredBlogList.add(blog);
                }
            }
        }
        return filteredBlogList;
    }
    
}
