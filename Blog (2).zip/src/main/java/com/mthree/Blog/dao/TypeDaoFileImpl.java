/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mthree.Blog.dao;

import com.mthree.Blog.dto.Type;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

/**
 *
 * @author jerry
 */
@Repository
public class TypeDaoFileImpl implements TypeDao {
    
    @Autowired
    JdbcTemplate jdbc;
     
    public static final class TypeMapper implements RowMapper<Type> {
        
        @Override
        public Type mapRow(ResultSet resultSet, int i) throws SQLException {
            Type role = new Type();

            role.setId(resultSet.getInt("id"));
            role.setName(resultSet.getString("name"));

            return role;
        }
    }
    
    @Override
    @Transactional
    public Type createType(Type model) {
        final String INSERT_ROLE = "INSERT INTO type (name) values (?)";
        jdbc.update(INSERT_ROLE, model.getName());

        int newId = jdbc.queryForObject("SELECT LAST_INSERT_ID()", Integer.class);
        model.setId(newId);

        return model;
    }

    @Override
    public List<Type> readAllTypes() {
        final String SELECT_ALL_ROLES = "SELECT * FROM type";
        return jdbc.query(SELECT_ALL_ROLES, new TypeMapper());
    }

    @Override
    public Type readTypeById(int id) {
        try {
            final String SELECT_ROLE_BY_ID = "SELECT * FROM type WHERE id = ?";
            return jdbc.queryForObject(SELECT_ROLE_BY_ID, new TypeMapper(), id);
        } catch (DataAccessException ex) {
            return null;
        }
    }

    @Override
    @Transactional
    public void updateType(Type model) {
        final String UPDATE_ROLE = "UPDATE type SET name = ? WHERE id = ?";
        jdbc.update(UPDATE_ROLE, model.getName(), model.getId());
    }

    @Override
    @Transactional
    public void deleteType(int id) {
        final String DELETE_USER_ROLE = "DELETE FROM user_type WHERE roleId = ?";
        jdbc.update(DELETE_USER_ROLE, id);

        final String DELETE_ROLE = "DELETE FROM type WHERE id = ?";
        jdbc.update(DELETE_ROLE, id);
    }
    
}
