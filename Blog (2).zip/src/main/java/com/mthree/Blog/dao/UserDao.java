/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package com.mthree.Blog.dao;

import com.mthree.Blog.dto.Type;
import com.mthree.Blog.dto.User;
import java.util.List;

/**
 *
 * @author jerry
 */
public interface UserDao {
    List<User> readAllUsers();
    User readUserById(int id);
    User createUser(User model);
    void updateUser(User model);
    void deleteUser(int id);
    
}
