/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
 */
package com.mthree.Blog.dao;

import com.mthree.Blog.dto.Comment;
import com.mthree.Blog.dto.Content;
import com.mthree.Blog.dto.Tag;
import com.mthree.Blog.dto.Type;
import com.mthree.Blog.dto.User;
import java.util.List;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

/**
 *
 * @author jerry
 */
@RunWith(SpringRunner.class)
@SpringBootTest
class TagDaoFileImplTest {
    
    @Autowired
    TypeDao typeDao;

    @Autowired
    UserDao userDao;

    @Autowired
    ContentDao contentDao;

    @Autowired
    TagDao tagDao;

    @Autowired
    CommentDao commentDao;

    @BeforeEach
    void setUp() {
        List<Type> roleList = typeDao.readAllTypes();
        for (Type role : roleList) {
            typeDao.deleteType(role.getId());
        }
        List<User> userList = userDao.readAllUsers();
        for (User user : userList) {
            userDao.deleteUser(user.getId());
        }
        List<Content> contentList = contentDao.readAllContent();
        for (Content content : contentList) {
            userDao.deleteUser(content.getId());
        }
        List<Comment> commentList = commentDao.readAllComments();
        for (Comment comment : commentList) {
            commentDao.deleteComment(comment.getId());
        }
        List<Tag> tagList = tagDao.readAllTags();
        for (Tag tag : tagList) {
            tagDao.deleteTag(tag.getId());
        }
    }
    
    @AfterEach
    void tearDown() {
    }


    @Test
    void create() {
        Tag tag = new Tag();
        tag.setName("tag1");
        tag = tagDao.createTag(tag);

        Tag fromDao = tagDao.readTagById(tag.getId());
        assertEquals(tag, fromDao);
    }

    @Test
    void readAll() {
        Tag tag = new Tag();
        tag.setName("tag1");
        tag = tagDao.createTag(tag);
        Tag tag2 = new Tag();
        tag2.setName("tag2");
        tag2 = tagDao.createTag(tag2);
        Tag tag3 = new Tag();
        tag3.setName("tag3");
        tag3 = tagDao.createTag(tag3);

        List<Tag> fromDao = tagDao.readAllTags();
        assertEquals(3, fromDao.size());
    }

    @Test
    void readById() {
        Tag tag = new Tag();
        tag.setName("tag1");
        tag = tagDao.createTag(tag);
        Tag tag2 = new Tag();
        tag2.setName("tag2");
        tag2 = tagDao.createTag(tag2);
        Tag tag3 = new Tag();
        tag3.setName("tag3");
        tag3 = tagDao.createTag(tag3);

        Tag fromDao = tagDao.readTagById(tag.getId());
        assertEquals(tag, fromDao);
    }

    @Test
    void update() {
        Tag tag = new Tag();
        tag.setName("tag1");
        tag = tagDao.createTag(tag);

        tag.setName("changed");
        tagDao.updateTag(tag);

        Tag fromDao = tagDao.readTagById(tag.getId());
        assertEquals(tag, fromDao);
    }

    @Test
    void delete() {
        Tag tag = new Tag();
        tag.setName("tag1");
        tag = tagDao.createTag(tag);
        Tag tag2 = new Tag();
        tag2.setName("tag2");
        tag2 = tagDao.createTag(tag2);
        Tag tag3 = new Tag();
        tag3.setName("tag3");
        tag3 = tagDao.createTag(tag3);

        tagDao.deleteTag(tag.getId());

        List<Tag> fromDao = tagDao.readAllTags();
        assertEquals(2, fromDao.size());
    }
}
