/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
 */
package com.mthree.Blog.dao;

import com.mthree.Blog.dto.Comment;
import com.mthree.Blog.dto.Content;
import com.mthree.Blog.dto.Tag;
import com.mthree.Blog.dto.Type;
import com.mthree.Blog.dto.User;
import java.util.ArrayList;
import java.util.List;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

/**
 *
 * @author jerry
 */
@RunWith(SpringRunner.class)
@SpringBootTest
public class UserDaoFileImplTest {
    
    @Autowired
    TypeDao roleDao;

    @Autowired
    UserDao userDao;

    @Autowired
    ContentDao contentDao;

    @Autowired
    TagDao tagDao;

    @Autowired
    CommentDao commentDao;

     @BeforeEach
    void setUp() {
        List<Type> roleList = roleDao.readAllTypes();
        for (Type role : roleList) {
            roleDao.deleteType(role.getId());
        }
        List<User> userList = userDao.readAllUsers();
        for (User user : userList) {
            userDao.deleteUser(user.getId());
        }
        List<Content> contentList = contentDao.readAllContent();
        for (Content content : contentList) {
            userDao.deleteUser(content.getId());
        }
        List<Comment> commentList = commentDao.readAllComments();
        for (Comment comment : commentList) {
            commentDao.deleteComment(comment.getId());
        }
        List<Tag> tagList = tagDao.readAllTags();
        for (Tag tag : tagList) {
            tagDao.deleteTag(tag.getId());
        }
    }

    @AfterEach
    void tearDown() {
    }

    @Test
    void create() {
        Type role = new Type();
        role.setName("role1");
        role = roleDao.createType(role);
        Type role2 = new Type();
        role2.setName("role2");
        role2 = roleDao.createType(role2);
        List<Type> roleList = new ArrayList<>();
        roleList.add(role);
        roleList.add(role2);

        User user = new User();
        user.setUsername("username1");
        user.setPassword("password");
        user.setFirstName("firstname1");
        user.setLastName("lastname1");
        user.setEnable(true);
        user.setPhone("1234567890");
        user.setEmail("test@gmail.com");
        user.setUserType(roleList);
        user = userDao.createUser(user);

        User fromDao = userDao.readUserById(user.getId());
        assertEquals(user, fromDao);
    }

    @Test
    void readAll() {
        Type role = new Type();
        role.setName("role1");
        role = roleDao.createType(role);
        Type role2 = new Type();
        role2.setName("role2");
        role2 = roleDao.createType(role2);
        List<Type> roleList = new ArrayList<>();
        roleList.add(role);
        roleList.add(role2);

        User user = new User();
        user.setUsername("username1");
        user.setPassword("password");
        user.setFirstName("firstname1");
        user.setLastName("lastname1");
        user.setEnable(true);
        user.setPhone("1234567890");
        user.setEmail("test@gmail.com");
        user.setUserType(roleList);
        user = userDao.createUser(user);
        User user2 = new User();
        user2.setUsername("username2");
        user2.setPassword("password");
        user2.setFirstName("firstname2");
        user2.setLastName("lastname2");
        user2.setEnable(true);
        user2.setPhone("1234567890");
        user2.setEmail("test@gmail.com");
        user2.setUserType(roleList);
        user2 = userDao.createUser(user2);

        List<User> fromDao = userDao.readAllUsers();
        assertEquals(2, fromDao.size());
    }

    @Test
    void readById() {
        Type role = new Type();
        role.setName("role1");
        role = roleDao.createType(role);
        Type role2 = new Type();
        role2.setName("role2");
        role2 = roleDao.createType(role2);
        List<Type> roleList = new ArrayList<>();
        roleList.add(role);
        roleList.add(role2);

        User user = new User();
        user.setUsername("username1");
        user.setPassword("password");
        user.setFirstName("firstname1");
        user.setLastName("lastname1");
        user.setEnable(true);
        user.setPhone("1234567890");
        user.setEmail("test@gmail.com");
        user.setUserType(roleList);
        user = userDao.createUser(user);
        User user2 = new User();
        user2.setUsername("username2");
        user2.setPassword("password");
        user2.setFirstName("firstname2");
        user2.setLastName("lastname2");
        user2.setEnable(true);
        user2.setPhone("1234567890");
        user2.setEmail("test@gmail.com");
        user2.setUserType(roleList);
        user2 = userDao.createUser(user2);

        User fromDao = userDao.readUserById(user2.getId());
        assertEquals(user2, fromDao);
    }

    @Test
    void update() {
        Type role = new Type();
        role.setName("role1");
        role = roleDao.createType(role);
        Type role2 = new Type();
        role2.setName("role2");
        role2 = roleDao.createType(role2);
        List<Type> roleList = new ArrayList<>();
        roleList.add(role);
        roleList.add(role2);

        User user = new User();
        user.setUsername("username1");
        user.setPassword("password");
        user.setFirstName("firstname1");
        user.setLastName("lastname1");
        user.setEnable(true);
        user.setPhone("1234567890");
        user.setEmail("test@gmail.com");
        user.setUserType(roleList);
        user = userDao.createUser(user);

        user.setFirstName("changed");
        user.setLastName("changed");
        userDao.updateUser(user);

        User fromDao = userDao.readUserById(user.getId());
        assertEquals(user, fromDao);
        assertEquals("changed", fromDao.getFirstName());
    }

    @Test
    void delete() {
        Type role = new Type();
        role.setName("role1");
        role = roleDao.createType(role);
        Type role2 = new Type();
        role2.setName("role2");
        role2 = roleDao.createType(role2);
        List<Type> roleList = new ArrayList<>();
        roleList.add(role);
        roleList.add(role2);

        User user = new User();
        user.setUsername("username1");
        user.setPassword("password");
        user.setFirstName("firstname1");
        user.setLastName("lastname1");
        user.setEnable(true);
        user.setPhone("1234567890");
        user.setEmail("test@gmail.com");
        user.setUserType(roleList);
        user = userDao.createUser(user);
        User user2 = new User();
        user2.setUsername("username2");
        user2.setPassword("password");
        user2.setFirstName("firstname2");
        user2.setLastName("lastname2");
        user2.setEnable(true);
        user2.setPhone("1234567890");
        user2.setEmail("test@gmail.com");
        user2.setUserType(roleList);
        user2 = userDao.createUser(user2);

        userDao.deleteUser(user2.getId());

        List<User> fromDao = userDao.readAllUsers();
        assertEquals(1, fromDao.size());
    }
    
}
