/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
 */
package com.mthree.Blog.dao;

import com.mthree.Blog.dto.Comment;
import com.mthree.Blog.dto.Content;
import com.mthree.Blog.dto.Tag;
import com.mthree.Blog.dto.Type;
import com.mthree.Blog.dto.User;
import java.time.LocalDateTime;
import java.util.List;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

/**
 *
 * @author jerry
 */
@RunWith(SpringRunner.class)
@SpringBootTest
public class CommentDaoFileImplTest {
    
    @Autowired
    TypeDao typeDao;

    @Autowired
    UserDao userDao;

    @Autowired
    ContentDao contentDao;

    @Autowired
    TagDao tagDao;

    @Autowired
    CommentDao commentDao;
    
   @BeforeEach
    void setUp() {
        List<Type> roleList = typeDao.readAllTypes();
        for (Type role : roleList) {
            typeDao.deleteType(role.getId());
        }
        List<User> userList = userDao.readAllUsers();
        for (User user : userList) {
            userDao.deleteUser(user.getId());
        }
        List<Content> contentList = contentDao.readAllContent();
        for (Content content : contentList) {
            userDao.deleteUser(content.getId());
        }
        List<Comment> commentList = commentDao.readAllComments();
        for (Comment comment : commentList) {
            commentDao.deleteComment(comment.getId());
        }
        List<Tag> tagList = tagDao.readAllTags();
        for (Tag tag : tagList) {
            tagDao.deleteTag(tag.getId());
        }
    }

    @AfterEach
    void tearDown() {
    }

    @Test
    void create() {
        Type role = new Type();
        role.setName("role1");
        role = typeDao.createType(role);
        List<Type> roleList = typeDao.readAllTypes();

        User user = new User();
        user.setUsername("username1");
        user.setPassword("password");
        user.setFirstName("firstname1");
        user.setLastName("lastname1");
        user.setEnable(true);
        user.setPhone("1234567890");
        user.setEmail("test@gmail.com");
        user.setUserType(roleList);
        user = userDao.createUser(user);

        Tag tag = new Tag();
        tag.setName("tag1");
        tag = tagDao.createTag(tag);
        List<Tag> tagList = tagDao.readAllTags();

        Content content = new Content();
        content.setDateCreated(LocalDateTime.parse("2020-01-01T12:45:30"));
        content.setTitle("title");
        content.setContent("content");
        content.setType("type");
        content.setStatus("status");
        content.setUser(user);
        content.setTags(tagList);
        content = contentDao.createContent(content);

        Comment comment = new Comment();
        comment.setDateCreated(LocalDateTime.parse("2020-01-01T12:45:30"));
        comment.setComment("comment");
        comment.setContentId(content);
        comment.setUserId(user);
        comment = commentDao.createComment(comment);

        Comment fromDao = commentDao.readCommentById(comment.getId());
        assertEquals(comment, fromDao);
    }

    @Test
    void readAll() {
        Type role = new Type ();
        role.setName("role1");
        role = typeDao.createType(role);
        List<Type> roleList = typeDao.readAllTypes();

        User user = new User();
        user.setUsername("username1");
        user.setPassword("password");
        user.setFirstName("firstname1");
        user.setLastName("lastname1");
        user.setEnable(true);
        user.setPhone("1234567890");
        user.setEmail("test@gmail.com");
        user.setUserType(roleList);
        user = userDao.createUser(user);

        Tag tag = new Tag();
        tag.setName("tag1");
        tag = tagDao.createTag(tag);
        List<Tag> tagList = tagDao.readAllTags();

        Content content = new Content();
        content.setDateCreated(LocalDateTime.parse("2020-01-01T12:45:30"));
        content.setTitle("title");
        content.setContent("content");
        content.setType("type");
        content.setStatus("status");
        content.setUser(user);
        content.setTags(tagList);
        content = contentDao.createContent(content);

        Comment comment = new Comment();
        comment.setDateCreated(LocalDateTime.parse("2020-01-01T12:45:30"));
        comment.setComment("comment");
        comment.setContentId(content);
        comment.setUserId(user);
        comment = commentDao.createComment(comment);
        Comment comment2 = new Comment();
        comment2.setDateCreated(LocalDateTime.parse("2020-01-01T12:45:30"));
        comment2.setComment("comment2");
        comment2.setContentId(content);
        comment2.setUserId(user);
        comment2 = commentDao.createComment(comment2);

        List<Comment> formDao = commentDao.readAllComments();
        assertEquals(2, formDao.size());
    }

    @Test
    void readById() {
        Type role = new Type();
        role.setName("role1");
        role = typeDao.createType(role);
        List<Type> roleList = typeDao.readAllTypes();

        User user = new User();
        user.setUsername("username1");
        user.setPassword("password");
        user.setFirstName("firstname1");
        user.setLastName("lastname1");
        user.setEnable(true);
        user.setPhone("1234567890");
        user.setEmail("test@gmail.com");
        user.setUserType(roleList);
        user = userDao.createUser(user);

        Tag tag = new Tag();
        tag.setName("tag1");
        tag = tagDao.createTag(tag);
        List<Tag> tagList = tagDao.readAllTags();

        Content content = new Content();
        content.setDateCreated(LocalDateTime.parse("2020-01-01T12:45:30"));
        content.setTitle("title");
        content.setContent("content");
        content.setType("type");
        content.setStatus("status");
        content.setUser(user);
        content.setTags(tagList);
        content = contentDao.createContent(content);

        Comment comment = new Comment();
        comment.setDateCreated(LocalDateTime.parse("2020-01-01T12:45:30"));
        comment.setComment("comment");
        comment.setContentId(content);
        comment.setUserId(user);
        comment = commentDao.createComment(comment);
        Comment comment2 = new Comment();
        comment2.setDateCreated(LocalDateTime.parse("2020-01-01T12:45:30"));
        comment2.setComment("comment2");
        comment2.setContentId(content);
        comment2.setUserId(user);
        comment2 = commentDao.createComment(comment2);

        Comment fromDao = commentDao.readCommentById(comment2.getId());
        assertEquals(comment2, fromDao);
    }

    @Test
    void update() {
        Type role = new Type();
        role.setName("role1");
        role = typeDao.createType(role);
        List<Type> roleList = typeDao.readAllTypes();

        User user = new User();
        user.setUsername("username1");
        user.setPassword("password");
        user.setFirstName("firstname1");
        user.setLastName("lastname1");
        user.setEnable(true);
        user.setPhone("1234567890");
        user.setEmail("test@gmail.com");
        user.setUserType(roleList);
        user = userDao.createUser(user);

        Tag tag = new Tag();
        tag.setName("tag1");
        tag = tagDao.createTag(tag);
        List<Tag> tagList = tagDao.readAllTags();

        Content content = new Content();
        content.setDateCreated(LocalDateTime.parse("2020-01-01T12:45:30"));
        content.setTitle("title");
        content.setContent("content");
        content.setType("type");
        content.setStatus("status");
        content.setUser(user);
        content.setTags(tagList);
        content = contentDao.createContent(content);

        Comment comment = new Comment();
        comment.setDateCreated(LocalDateTime.parse("2020-01-01T12:45:30"));
        comment.setComment("comment");
        comment.setContentId(content);
        comment.setUserId(user);
        comment = commentDao.createComment(comment);

        comment.setComment("changed");
        commentDao.updateComment(comment);

        Comment fromDao = commentDao.readCommentById(comment.getId());


    }

    @Test
    void delete() {
        Type role = new Type();
        role.setName("role1");
        role = typeDao.createType(role);
        List<Type> roleList = typeDao.readAllTypes();

        User user = new User();
        user.setUsername("username1");
        user.setPassword("password");
        user.setFirstName("firstname1");
        user.setLastName("lastname1");
        user.setEnable(true);
        user.setPhone("1234567890");
        user.setEmail("test@gmail.com");
        user.setUserType(roleList);
        user = userDao.createUser(user);

        Tag tag = new Tag();
        tag.setName("tag1");
        tag = tagDao.createTag(tag);
        List<Tag> tagList = tagDao.readAllTags();

        Content content = new Content();
        content.setDateCreated(LocalDateTime.parse("2020-01-01T12:45:30"));
        content.setTitle("title");
        content.setContent("content");
        content.setType("type");
        content.setStatus("status");
        content.setUser(user);
        content.setTags(tagList);
        content = contentDao.createContent(content);

        Comment comment = new Comment();
        comment.setDateCreated(LocalDateTime.parse("2020-01-01T12:45:30"));
        comment.setComment("comment");
        comment.setContentId(content);
        comment.setUserId(user);
        comment = commentDao.createComment(comment);
        Comment comment2 = new Comment();
        comment2.setDateCreated(LocalDateTime.parse("2020-01-01T12:45:30"));
        comment2.setComment("comment2");
        comment2.setContentId(content);
        comment2.setUserId(user);
        comment2 = commentDao.createComment(comment2);

        commentDao.deleteComment(comment2.getId());

        List<Comment> formDao = commentDao.readAllComments();
        assertEquals(1, formDao.size());
    }
    
}
