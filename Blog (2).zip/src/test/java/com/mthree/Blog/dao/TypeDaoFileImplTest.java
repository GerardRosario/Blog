/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
 */
package com.mthree.Blog.dao;

import com.mthree.Blog.dto.Comment;
import com.mthree.Blog.dto.Content;
import com.mthree.Blog.dto.Tag;
import com.mthree.Blog.dto.Type;
import com.mthree.Blog.dto.User;
import java.util.List;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

/**
 *
 * @author jerry
 */
@RunWith(SpringRunner.class)
@SpringBootTest
class TypeDaoFileImplTest {
    
    @Autowired
    TypeDao typeDao;

    @Autowired
    UserDao userDao;

    @Autowired
    ContentDao contentDao;

    @Autowired
    TagDao tagDao;

    @Autowired
    CommentDao commentDao;
    
     @BeforeEach
    void setUp() {
        List<Type> roleList = typeDao.readAllTypes();
        for (Type role : roleList) {
            typeDao.deleteType(role.getId());
        }
        List<User> userList = userDao.readAllUsers();
        for (User user : userList) {
            userDao.deleteUser(user.getId());
        }
        List<Content> contentList = contentDao.readAllContent();
        for (Content content : contentList) {
            userDao.deleteUser(content.getId());
        }
        List<Comment> commentList = commentDao.readAllComments();
        for (Comment comment : commentList) {
            commentDao.deleteComment(comment.getId());
        }
        List<Tag> tagList = tagDao.readAllTags();
        for (Tag tag : tagList) {
            tagDao.deleteTag(tag.getId());
        }
    }

    @AfterEach
    void tearDown() {
    }

    @Test
    void create() {
        Type role = new Type();
        role.setName("role1");
        role = typeDao.createType(role);

        Type fromDao = typeDao.readTypeById(role.getId());
        assertEquals(role, fromDao);
    }

    @Test
    void readAll() {
        Type role = new Type();
        role.setName("role1");
        role = typeDao.createType(role);
        Type role2 = new Type();
        role2.setName("role2");
        role2 = typeDao.createType(role2);

        List<Type> fromDao = typeDao.readAllTypes();
        assertEquals(2, fromDao.size());
    }

    @Test
    void readById() {
        Type role = new Type();
        role.setName("role1");
        role = typeDao.createType(role);
        Type role2 = new Type();
        role2.setName("role2");
        role2 = typeDao.createType(role2);

        Type fromDao = typeDao.readTypeById(role2.getId());
        assertEquals(role2, fromDao);
    }

    @Test
    void update() {
        Type role = new Type();
        role.setName("role1");
        role = typeDao.createType(role);

        role.setName("Changed");
        typeDao.updateType(role);

        Type fromDao = typeDao.readTypeById(role.getId());
        assertEquals(role, fromDao);
    }

    @Test
    void delete() {
        Type role = new Type();
        role.setName("role1");
        role = typeDao.createType(role);
        Type role2 = new Type();
        role2.setName("role2");
        role2 = typeDao.createType(role2);

        typeDao.deleteType(role2.getId());

        List<Type> fromDao = typeDao.readAllTypes();
        assertEquals(1, fromDao.size());
    }
    
}
