/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
 */
package com.mthree.Blog.dao;

import com.mthree.Blog.dto.Comment;
import com.mthree.Blog.dto.Content;
import com.mthree.Blog.dto.Tag;
import com.mthree.Blog.dto.Type;
import com.mthree.Blog.dto.User;
import java.time.LocalDateTime;
import java.util.List;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

/**
 *
 * @author jerry
 */
@RunWith(SpringRunner.class)
@SpringBootTest
public class ContentDaoFileImplTest {
    
    @Autowired
    TypeDao typeDao;

    @Autowired
    UserDao userDao;

    @Autowired
    ContentDao contentDao;

    @Autowired
    TagDao tagDao;

    @Autowired
    CommentDao commentDao;
    
    @BeforeEach
    void setUp() {
        List<Type> roleList = typeDao.readAllTypes();
        for (Type role : roleList) {
            typeDao.deleteType(role.getId());
        }
        List<User> userList = userDao.readAllUsers();
        for (User user : userList) {
            userDao.deleteUser(user.getId());
        }
        List<Content> contentList = contentDao.readAllContent();
        for (Content content : contentList) {
            userDao.deleteUser(content.getId());
        }
        List<Comment> commentList = commentDao.readAllComments();
        for (Comment comment : commentList) {
            commentDao.deleteComment(comment.getId());
        }
        List<Tag> tagList = tagDao.readAllTags();
        for (Tag tag : tagList) {
            tagDao.deleteTag(tag.getId());
        }
    }

    @AfterEach
    void tearDown() {
    }

    @Test
    void create() {
        Type role = new Type();
        role.setName("role1");
        role = typeDao.createType(role);
        List<Type> roleList = typeDao.readAllTypes();

        User user = new User();
        user.setUsername("username1");
        user.setPassword("password");
        user.setFirstName("firstname1");
        user.setLastName("lastname1");
        user.setEnable(true);
        user.setPhone("1234567890");
        user.setEmail("test@gmail.com");
        user.setUserType(roleList);
        user = userDao.createUser(user);

        Tag tag = new Tag();
        tag.setName("tag1");
        tag = tagDao.createTag(tag);
        List<Tag> tagList = tagDao.readAllTags();

        Content content = new Content();
        content.setDateCreated(LocalDateTime.parse("2020-01-01T12:45:30"));
        content.setTitle("title");
        content.setContent("content");
        content.setType("type");
        content.setStatus("status");
        content.setUser(user);
        content.setTags(tagList);
        content = contentDao.createContent(content);

        Content fromDao = contentDao.readContentById(content.getId());
        assertEquals(content, fromDao);
    }

    @Test
    void readAll() {
        Type role = new Type();
        role.setName("role1");
        role = typeDao.createType(role);
        List<Type> roleList = typeDao.readAllTypes();

        User user = new User();
        user.setUsername("username1");
        user.setPassword("password");
        user.setFirstName("firstname1");
        user.setLastName("lastname1");
        user.setEnable(true);
        user.setPhone("1234567890");
        user.setEmail("test@gmail.com");
        user.setUserType(roleList);
        user = userDao.createUser(user);

        Tag tag = new Tag();
        tag.setName("tag1");
        tag = tagDao.createTag(tag);
        List<Tag> tagList = tagDao.readAllTags();

        Content content = new Content();
        content.setDateCreated(LocalDateTime.parse("2020-01-01T12:45:30"));
        content.setTitle("title");
        content.setContent("content");
        content.setType("type");
        content.setStatus("status");
        content.setUser(user);
        content.setTags(tagList);
        content = contentDao.createContent(content);
        Content content2 = new Content();
        content2.setDateCreated(LocalDateTime.parse("2020-01-01T12:45:30"));
        content2.setTitle("title2");
        content2.setContent("content2");
        content2.setType("type");
        content2.setStatus("status");
        content2.setUser(user);
        content2.setTags(tagList);
        content2 = contentDao.createContent(content2);

        List<Content> fromDao = contentDao.readAllContent();
        assertEquals(2, fromDao.size());
    }

    @Test
    void readById() {
        Type role = new Type();
        role.setName("role1");
        role = typeDao.createType(role);
        List<Type> roleList = typeDao.readAllTypes();

        User user = new User();
        user.setUsername("username1");
        user.setPassword("password");
        user.setFirstName("firstname1");
        user.setLastName("lastname1");
        user.setEnable(true);
        user.setPhone("1234567890");
        user.setEmail("test@gmail.com");
        user.setUserType(roleList);
        user = userDao.createUser(user);

        Tag tag = new Tag();
        tag.setName("tag1");
        tag = tagDao.createTag(tag);
        List<Tag> tagList = tagDao.readAllTags();

        Content content = new Content();
        content.setDateCreated(LocalDateTime.parse("2020-01-01T12:45:30"));
        content.setTitle("title");
        content.setContent("content");
        content.setType("type");
        content.setStatus("status");
        content.setUser(user);
        content.setTags(tagList);
        content = contentDao.createContent(content);
        Content content2 = new Content();
        content2.setDateCreated(LocalDateTime.parse("2020-01-01T12:45:30"));
        content2.setTitle("title2");
        content2.setContent("content2");
        content2.setType("type");
        content2.setStatus("status");
        content2.setUser(user);
        content2.setTags(tagList);
        content2 = contentDao.createContent(content2);

        Content fromDao = contentDao.readContentById(content2.getId());
        assertEquals(content2, fromDao);
    }

    @Test
    void update() {
        Type role = new Type();
        role.setName("role1");
        role = typeDao.createType(role);
        List<Type> roleList = typeDao.readAllTypes();

        User user = new User();
        user.setUsername("username1");
        user.setPassword("password");
        user.setFirstName("firstname1");
        user.setLastName("lastname1");
        user.setEnable(true);
        user.setPhone("1234567890");
        user.setEmail("test@gmail.com");
        user.setUserType(roleList);
        user = userDao.createUser(user);

        Tag tag = new Tag();
        tag.setName("tag1");
        tag = tagDao.createTag(tag);
        List<Tag> tagList = tagDao.readAllTags();

        Content content = new Content();
        content.setDateCreated(LocalDateTime.parse("2020-01-01T12:45:30"));
        content.setTitle("title");
        content.setContent("content");
        content.setType("type");
        content.setStatus("status");
        content.setUser(user);
        content.setTags(tagList);
        content = contentDao.createContent(content);

        content.setContent("changed");
        contentDao.updateContent(content);

        Content fromDao = contentDao.readContentById(content.getId());
        assertEquals(content, fromDao);
        assertEquals("changed", fromDao.getContent());
    }

    @Test
    void delete() {
        Type role = new Type();
        role.setName("role1");
        role = typeDao.createType(role);
        List<Type> roleList = typeDao.readAllTypes();

        User user = new User();
        user.setUsername("username1");
        user.setPassword("password");
        user.setFirstName("firstname1");
        user.setLastName("lastname1");
        user.setEnable(true);
        user.setPhone("1234567890");
        user.setEmail("test@gmail.com");
        user.setUserType(roleList);
        user = userDao.createUser(user);

        Tag tag = new Tag();
        tag.setName("tag1");
        tag = tagDao.createTag(tag);
        List<Tag> tagList = tagDao.readAllTags();

        Content content = new Content();
        content.setDateCreated(LocalDateTime.parse("2020-01-01T12:45:30"));
        content.setTitle("title");
        content.setContent("content");
        content.setType("type");
        content.setStatus("status");
        content.setUser(user);
        content.setTags(tagList);
        content = contentDao.createContent(content);
        Content content2 = new Content();
        content2.setDateCreated(LocalDateTime.parse("2020-01-01T12:45:30"));
        content2.setTitle("title2");
        content2.setContent("content2");
        content2.setType("type");
        content2.setStatus("status");
        content2.setUser(user);
        content2.setTags(tagList);
        content2 = contentDao.createContent(content2);

        contentDao.deleteContent(content2.getId());

        List<Content> fromDao = contentDao.readAllContent();
        assertEquals(1, fromDao.size());
    }
    
}
